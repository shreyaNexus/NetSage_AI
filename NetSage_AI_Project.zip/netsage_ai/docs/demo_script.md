# Demo Video Script (5–10 min)

Record screen + narration walking through **one broken lab case end to end**.
Suggested case to use on camera: **C001** (simple, visual, easy to reproduce
live in Packet Tracer) with a callback to **C009** (a case the AI got right
at the rule-checker level but originally missed as an AI diagnosis in an
earlier prompt draft — good for showing the review process actually catching
something).

## 1. Cold open (30 sec)
- One sentence on the problem: junior engineers can run commands but
  struggle to connect symptoms to root cause.
- One sentence on what NetSage AI does: AI-drafted diagnosis, always
  reviewed by a human before anything is applied.

## 2. Show the broken lab (1–2 min)
- Open Packet Tracer, show PC1 pinging PC2 and failing.
- Run `show vlan brief` on SW1 live, point out Fa0/2 sitting in VLAN 1.

## 3. Feed the case to NetSage AI (1–2 min)
- Show `prompts/diagnose_prompt.md` briefly — explain the forced JSON
  schema and why (root_cause, confidence, evidence, next_command, fix_steps).
- Show the case's row in `data/cases.csv` and its AI response in
  `data/ai_diagnoses.csv` (or run it live against the AI assistant if your
  team has API access set up).

## 4. Run the rule checker (1 min)
- `python3 scripts/rule_checker.py`
- Point out that C001 is independently flagged `missing_vlan` by the
  deterministic checker — two independent signals agreeing is what lets the
  team trust the diagnosis enough to apply the fix.

## 5. Human review (1–2 min)
- Open `review/human_review.csv`, find C001, show it's `Accepted`.
- Then show a `Rejected` example (e.g. C019 or C027) from
  `docs/responsible_ai_log.md` — explain why the AI was wrong there and how
  review caught it before anything was applied to a real device.

## 6. Apply the fix and verify (1 min)
- Back in Packet Tracer: `interface fa0/2`, `switchport access vlan 10`.
- Re-run `show vlan brief`, then re-test the ping — show it succeeding.

## 7. Dashboard (1 min)
- Open `dashboard/NetSage_AI_Dashboard.xlsx`, show the KPI row (Total
  Cases, Accepted/Edited/Rejected counts, AI Agreement Rate, Rule-Checker
  Clean Rate) and the two charts.
- One sentence on the current AI agreement rate and what the team is doing
  to improve it (see "Action items" in the Responsible AI log).

## 8. Close (15–30 sec)
- Restate the core takeaway: AI drafts, rules verify, humans decide.
