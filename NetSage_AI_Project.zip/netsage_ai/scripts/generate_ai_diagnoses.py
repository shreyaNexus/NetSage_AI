"""
NetSage AI - AI Diagnosis Log
Simulates "feed each case to the AI assistant, save the response" using the
JSON schema from prompts/diagnose_prompt.md. Six cases (C003, C009, C013,
C019, C023, C027) are deliberately imperfect/wrong, matching realistic LLM
failure modes on subtle or ambiguous evidence, so the human-review step has
real material to accept/edit/reject and the Responsible AI log has genuine
examples to document.
"""
import csv
import json

# case_id -> AI JSON response (as it would come back from the model)
AI = {
"C001": dict(root_cause="Fa0/2 is still in default VLAN 1 instead of VLAN 10, splitting PC1 and PC2 into different broadcast domains.",
    confidence="high", osi_layer="Layer 2",
    evidence="show vlan brief lists Fa0/2 under VLAN1, not VLAN10; show run int fa0/2 confirms 'switchport access vlan 1'.",
    next_command="show vlan brief",
    fix_steps=["interface fa0/2","switchport access vlan 10","confirm with show vlan brief","re-test ping PC1 to PC2"]),

"C002": dict(root_cause="VLAN 30 was assigned to ports but never created with the global 'vlan 30' command, so the ports are inactive.",
    confidence="high", osi_layer="Layer 2",
    evidence="show vlan brief has no VLAN30 entry at all even though fa0/5 is configured with 'switchport access vlan 30'.",
    next_command="show vlan brief",
    fix_steps=["vlan 30 (global config)","name Sales","exit","confirm VLAN30 now shows ACTIVE","re-test connectivity between the two ports"]),

"C003": dict(root_cause="The trunk between SW1 and SW2 is not carrying VLAN 20 at all, so VLAN 20 traffic never crosses the link.",
    confidence="medium", osi_layer="Layer 2",
    evidence="Both switches show VLAN20 configured locally; assumed the trunk's allowed-VLAN list excludes VLAN 20.",
    next_command="show interfaces trunk",
    fix_steps=["check switchport trunk allowed vlan on both ends","add vlan 20 to the allowed list if missing","re-test VLAN 20 connectivity across the trunk"]),

"C004": dict(root_cause="Fa0/8 was never assigned to VLAN 40 and is sitting in default VLAN 1.",
    confidence="high", osi_layer="Layer 2",
    evidence="show vlan brief places fa0/8 under VLAN1; show run int fa0/8 has no access vlan command.",
    next_command="show vlan brief",
    fix_steps=["interface fa0/8","switchport access vlan 40","confirm with show vlan brief","re-test printer reachability"]),

"C005": dict(root_cause="Router subinterface Gi0/0.10 (the VLAN 10 gateway) is administratively shut down.",
    confidence="high", osi_layer="Layer 3",
    evidence="show ip interface brief shows Gi0/0.10 administratively down; show run confirms a 'shutdown' line under that subinterface.",
    next_command="show ip interface brief",
    fix_steps=["interface Gi0/0.10","no shutdown","confirm status is up/up","re-test connectivity from VLAN 10 to other VLANs"]),

"C006": dict(root_cause="PC3's default gateway (192.168.6.1) is on a different subnet than the router's real interface (192.168.5.1).",
    confidence="high", osi_layer="Layer 3",
    evidence="PC3 ipconfig gateway is 192.168.6.1 while R1 Gi0/1 is 192.168.5.1/24.",
    next_command="show ip interface brief",
    fix_steps=["reconfigure PC3's gateway to 192.168.5.1","if via DHCP, fix the default-router option on the pool","re-test off-subnet connectivity"]),

"C007": dict(root_cause="The laptop's gateway address has a typo (172.16.1.001) and never matches the router's real interface (172.16.1.1).",
    confidence="high", osi_layer="Layer 3",
    evidence="Laptop ipconfig shows gateway 172.16.1.001 vs router Gi0/0 at 172.16.1.1.",
    next_command="ipconfig /all",
    fix_steps=["correct the static gateway to 172.16.1.1","or switch the laptop to DHCP","re-test connectivity beyond the local subnet"]),

"C008": dict(root_cause="Branch router Gi0/1, the LAN gateway interface, is line-protocol down.",
    confidence="high", osi_layer="Layer 1/2",
    evidence="show ip int brief reports Gi0/1 down/down; log shows %LINK-3-UPDOWN changed state to down.",
    next_command="show interfaces Gi0/1",
    fix_steps=["check the physical cable/SFP on Gi0/1","reseat or replace the cable","no shutdown if administratively disabled","confirm up/up and re-test LAN connectivity"]),

"C009": dict(root_cause="PC5's default gateway address is wrong; it should point at 192.168.20.1 like the router interface shows.",
    confidence="medium", osi_layer="Layer 3",
    evidence="PC5's gateway differs from what the router reports for that segment.",
    next_command="ipconfig /all",
    fix_steps=["reconfigure PC5's gateway to match the router interface","re-test connectivity"]),

"C010": dict(root_cause="The DHCP scope for VLAN 50 is fully leased out (50/50), so new clients fall back to APIPA.",
    confidence="high", osi_layer="Layer 3",
    evidence="show ip dhcp pool LAB50 reports leased 50 of 50; debug shows DHCPDISCOVER with no addresses available.",
    next_command="show ip dhcp pool LAB50",
    fix_steps=["enlarge the DHCP pool's address range","or shorten the lease time to recycle stale leases","clear expired bindings with clear ip dhcp binding *","re-test that new clients receive an address"]),

"C011": dict(root_cause="The router's own gateway address (10.10.60.1) was never excluded from the DHCP pool and got leased to a client.",
    confidence="high", osi_layer="Layer 3",
    evidence="show ip dhcp binding shows 10.10.60.1 leased to a client MAC; no ip dhcp excluded-address command is present for it.",
    next_command="show ip dhcp binding",
    fix_steps=["ip dhcp excluded-address 10.10.60.1 10.10.60.10","clear the bad lease with clear ip dhcp binding 10.10.60.1","re-test that the client gets a different address"]),

"C012": dict(root_cause="VLAN 70's gateway interface is missing 'ip helper-address', so DHCP broadcasts never reach the remote server.",
    confidence="high", osi_layer="Layer 3",
    evidence="show run int vlan70 has no ip helper-address line; debug shows no DHCPDISCOVER arriving at the server interface.",
    next_command="show run interface vlan70",
    fix_steps=["interface vlan70","ip helper-address <dhcp-server-ip>","re-test that VLAN 70 clients receive a lease"]),

"C013": dict(root_cause="Clients on VLAN 80 are not receiving any default gateway from DHCP at all.",
    confidence="low", osi_layer="Layer 3",
    evidence="Browsing fails after clients get an IP, suggesting a gateway or DNS problem in the DHCP scope.",
    next_command="show run | section dhcp pool LAB80",
    fix_steps=["review the DHCP pool configuration for LAB80","verify the default-router and dns-server options"]),

"C014": dict(root_cause="The internal DNS server at 10.10.1.53 is unreachable, so name resolution fails even though the target service's IP is fine.",
    confidence="high", osi_layer="Layer 7",
    evidence="Ping to 10.10.1.53 times out while ping to the web server's IP succeeds.",
    next_command="ping 10.10.1.53",
    fix_steps=["check the DNS server's power/interface status","verify routing/ACLs toward 10.10.1.53","restart the DNS service if the host is reachable but not answering on port 53","re-test nslookup"]),

"C015": dict(root_cause="This PC's statically configured DNS server IP has a digit transposition (10.10.1.35 instead of 10.10.1.53).",
    confidence="high", osi_layer="Layer 7",
    evidence="ipconfig /all shows DNS 10.10.1.35, which is unreachable, while the correct server is 10.10.1.53.",
    next_command="ipconfig /all",
    fix_steps=["correct the static DNS entry to 10.10.1.53","or switch the PC back to DHCP-assigned DNS","re-test nslookup"]),

"C016": dict(root_cause="A newly added ACL entry on the WAN link denies UDP port 53, blocking DNS while ICMP still passes.",
    confidence="high", osi_layer="Layer 3/4",
    evidence="show access-lists WAN-IN shows 'deny udp any any eq 53' ahead of the permit statements; ping still succeeds, isolating this to port 53 specifically.",
    next_command="show access-lists WAN-IN",
    fix_steps=["remove or reorder the deny udp eq 53 line","add an explicit permit for udp any any eq 53 if DNS should be allowed","re-test nslookup from the branch"]),

"C017": dict(root_cause="No DNS A record exists for the new app server, so the hostname simply does not resolve.",
    confidence="high", osi_layer="Layer 7",
    evidence="nslookup returns non-existent domain and the DNS zone has no A record for appserver.",
    next_command="show zone internal.local (or check DNS server console)",
    fix_steps=["create an A record for appserver.local pointing to 10.10.9.30","re-test nslookup","re-test browsing by hostname"]),

"C018": dict(root_cause="HQ is missing the static route to the branch LAN subnet 172.20.5.0/24, so return traffic has nowhere to go.",
    confidence="high", osi_layer="Layer 3",
    evidence="HQ show ip route has no entry for 172.20.5.0/24; the corresponding ip route statement is absent from the running config.",
    next_command="show ip route 172.20.5.0",
    fix_steps=["ip route 172.20.5.0 255.255.255.0 <branch-wan-ip>","confirm the route appears in show ip route","re-test ping from HQ to a branch LAN host"]),

"C019": dict(root_cause="OSPF is not enabled on the R1-R2 link interface, so no neighbor relationship ever forms.",
    confidence="medium", osi_layer="Layer 3",
    evidence="show ip ospf neighbor is empty on R1, suggesting OSPF is not running on that interface.",
    next_command="show ip ospf interface brief",
    fix_steps=["confirm the interface is included in the OSPF network statement or has 'ip ospf 1 area 0' applied","re-test neighbor formation"]),

"C020": dict(root_cause="The default route's next-hop IP (203.0.113.254) is wrong; the real ISP hand-off is 203.0.113.253.",
    confidence="high", osi_layer="Layer 3",
    evidence="Ping to the configured next hop 203.0.113.254 times out, indicating that address does not answer on the WAN link.",
    next_command="show ip route 0.0.0.0",
    fix_steps=["update the static route: ip route 0.0.0.0 0.0.0.0 203.0.113.253","remove the old incorrect static route","re-test internet reachability"]),

"C021": dict(root_cause="A policy-based routing map is sending return traffic out a misconfigured interface, causing asymmetric routing.",
    confidence="medium", osi_layer="Layer 3",
    evidence="Traceroute A-to-B is clean but B-to-A dies at the last hop; the route-map POLICY forces the return path onto a different interface.",
    next_command="show route-map POLICY",
    fix_steps=["review the route-map's match/set statements for the return direction","correct the set interface/next-hop to match the intended path","re-test bidirectional traceroute"]),

"C022": dict(root_cause="The new PAYROLL-IN ACL only permits TCP 443, so the app's real port (8443) is caught by the implicit deny.",
    confidence="high", osi_layer="Layer 3/4",
    evidence="show access-lists PAYROLL-IN only has a permit for eq 443; hit counters show the implicit deny incrementing heavily.",
    next_command="show access-lists PAYROLL-IN",
    fix_steps=["add: permit tcp 10.10.11.0 0.0.0.255 host 10.10.99.5 eq 8443","re-test HR access to the payroll app","confirm implicit-deny hit counter stops climbing"]),

"C023": dict(root_cause="The ACL is missing a deny statement for host 10.10.12.50 entirely, which is why it still gets through.",
    confidence="medium", osi_layer="Layer 3/4",
    evidence="show access-lists BLOCK-HOST lists a permit for the subnet; assumed the specific deny line was never added.",
    next_command="show access-lists BLOCK-HOST",
    fix_steps=["add a deny statement for host 10.10.12.50 to the ACL","re-test that the host is now blocked"]),

"C024": dict(root_cause="The LAB-ACL is applied in the wrong direction ('out' instead of 'in') on the VLAN 90 interface.",
    confidence="high", osi_layer="Layer 3/4",
    evidence="show run int vlan90 shows 'ip access-group LAB-ACL out', but the ACL's permit rules are written for inbound HTTP.",
    next_command="show run interface vlan90",
    fix_steps=["remove: ip access-group LAB-ACL out","add: ip access-group LAB-ACL in","re-test inbound HTTP to the test server from outside"]),

"C025": dict(root_cause="ACL 101 is a stateless list that only permits outbound DNS queries and has no matching entry for return traffic, so responses are dropped.",
    confidence="high", osi_layer="Layer 3/4",
    evidence="show access-lists 101 shows only 'permit udp 10.10.13.0 0.0.0.255 any eq 53' with nothing allowing the reply traffic back in.",
    next_command="show access-lists 101",
    fix_steps=["add a permit for udp any eq 53 10.10.13.0 0.0.0.255 on the return leg, or replace with a reflexive/extended ACL that tracks established sessions","re-test DNS resolution from VLAN 13"]),

"C026": dict(root_cause="'ip nat inside' and 'ip nat outside' were never applied to the LAN and WAN interfaces, so the NAT rule has nothing to act on.",
    confidence="high", osi_layer="Layer 3",
    evidence="show ip interface shows neither Gi0/1 nor Gi0/0 marked with a NAT role, even though the overload rule exists in the config.",
    next_command="show ip interface Gi0/1",
    fix_steps=["interface Gi0/1 / ip nat inside","interface Gi0/0 / ip nat outside","re-test internet access from an internal host","confirm entries appear in show ip nat translations"]),

"C027": dict(root_cause="NAT overload is not enabled at all for this subnet, which is why most hosts cannot reach the internet.",
    confidence="low", osi_layer="Layer 3",
    evidence="Only a few hosts show up in show ip nat translations, suggesting NAT overload was never turned on for the subnet.",
    next_command="show run | include ip nat",
    fix_steps=["verify ip nat inside source list 1 interface Gi0/0 overload is present","re-test internet access from an affected host"]),

"C028": dict(root_cause="No static NAT/port-forward rule exists for the internal web server, so inbound requests from outside are never translated.",
    confidence="high", osi_layer="Layer 3",
    evidence="show run has no matching 'ip nat inside source static tcp' line for 10.10.5.20; show ip nat translations has no static entry.",
    next_command="show ip nat translations",
    fix_steps=["ip nat inside source static tcp 10.10.5.20 80 interface Gi0/0 80","re-test reaching the server from outside the network","confirm the static entry appears in show ip nat translations"]),

"C029": dict(root_cause="The Guest SSID is mapped to VLAN 10 (internal/trusted) instead of the isolated VLAN 99, so guest traffic reaches internal servers.",
    confidence="high", osi_layer="Layer 2",
    evidence="show wlan 2 shows 'interface VLAN10' for the Guest SSID, and VLAN10 has no isolation ACL applied.",
    next_command="show wlan 2",
    fix_steps=["remap the Guest SSID's interface to VLAN 99","confirm VLAN 99 has the guest-isolation ACL applied","re-test that guest devices cannot reach internal servers"]),

"C030": dict(root_cause="The RADIUS server's shared secret was recently changed and needs to be updated on the WLC.",
    confidence="low", osi_layer="Layer 7",
    evidence="Multiple 802.1X authentication failures were logged, which could point to a RADIUS shared-secret mismatch.",
    next_command="show run | include radius",
    fix_steps=["verify the RADIUS shared secret on the WLC matches the RADIUS server","re-test authentication from an affected laptop"]),
}

FIELDS = ["case_id","root_cause","confidence","osi_layer","evidence","next_command","fix_steps_json"]

with open("/home/claude/netsage_ai/data/ai_diagnoses.csv", "w", newline="") as f:
    w = csv.DictWriter(f, fieldnames=FIELDS)
    w.writeheader()
    for case_id, d in AI.items():
        w.writerow({
            "case_id": case_id,
            "root_cause": d["root_cause"],
            "confidence": d["confidence"],
            "osi_layer": d["osi_layer"],
            "evidence": d["evidence"],
            "next_command": d["next_command"],
            "fix_steps_json": json.dumps(d["fix_steps"]),
        })

print(f"Wrote {len(AI)} AI diagnoses.")
