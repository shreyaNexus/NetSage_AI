"""
NetSage AI - Human Review Log
For every case, a human reviewer marks the AI's diagnosis as:
  Accepted - AI root cause matches the real fault, evidence and fix are solid
  Edited   - AI root cause was right but confidence/evidence/fix needed a tweak
  Rejected - AI root cause was wrong; reviewer supplies the corrected diagnosis
"""
import csv

REVIEW = {
"C001": ("Accepted", "", "AI matched the case exactly, evidence citation is precise."),
"C002": ("Accepted", "", "Correct diagnosis; fix steps are the standard VLAN-creation sequence."),
"C003": ("Rejected",
         "Native VLAN mismatch on the trunk (VLAN 1 on SW1 vs VLAN 99 on SW2) is causing VLAN 20 traffic to be mishandled, not a missing-VLAN-on-trunk issue.",
         "AI guessed 'VLAN 20 not in the allowed list' without evidence for it, and missed the CDP native-VLAN-mismatch warning that was explicitly in the show_output. Confidence was appropriately only medium, which is why this got caught before being applied."),
"C004": ("Accepted", "", "Correct and matches the show vlan brief evidence directly."),
"C005": ("Accepted", "", "Correct; administratively down subinterface is unambiguous in the evidence."),
"C006": ("Edited",
         "Same root cause, but reviewer added: 'if DHCP is in use for this segment, also check the pool's default-router option, not just the static config.'",
         "AI's diagnosis was correct; edited to broaden the fix so it still applies if the gateway turns out to be DHCP-assigned rather than static, since the case evidence didn't fully rule that out."),
"C007": ("Accepted", "", "Correct; the .001 typo is called out precisely."),
"C008": ("Accepted", "", "Correct; matches the down/down interface and log line directly."),
"C009": ("Rejected",
         "PC5 has the wrong subnet mask (/24 instead of /25) for a subnet that was split into two /25 blocks, so it wrongly treats the gateway as on-link. The gateway IP itself is correct.",
         "AI treated this as a generic 'wrong gateway IP' case and told the engineer to change the gateway address, which was already correct. The actual evidence (router interface using a /25 mask on a /24-looking network) points to a mask problem, not a gateway-address problem. This is a classic case where surface-level pattern matching ('gateway issue') led the AI astray on a subtler root cause."),
"C010": ("Accepted", "", "Correct; pool exhaustion is directly shown in show ip dhcp pool."),
"C011": ("Edited",
         "Same root cause, reviewer reordered fix_steps: exclude the address FIRST, then clear the bad binding, so a new client doesn't grab the same range again mid-fix.",
         "AI's diagnosis and fix were both correct in substance; edited only for operational sequencing."),
"C012": ("Accepted", "", "Correct; missing ip helper-address is the textbook cause and matches the debug evidence."),
"C013": ("Rejected",
         "The DHCP pool LAB80 is advertising the wrong default-router option (10.10.80.254) instead of the router's real interface (10.10.80.1), so clients get an IP but no working gateway.",
         "AI hedged with low confidence and a vague 'review the DHCP pool configuration' fix instead of committing to a specific hypothesis, even though the show_output directly contained the mismatched default-router line. This is logged as an under-confident miss: the evidence was sufficient to reach 'high' confidence and a specific fix, and the AI should not have needed a human to point at output that was already provided."),
"C014": ("Accepted", "", "Correct; DNS server unreachability is directly evidenced by the failed ping."),
"C015": ("Accepted", "", "Correct; the transposed digits are called out precisely."),
"C016": ("Edited",
         "Same root cause, reviewer added: 'confirm no other ACL later in the chain also blocks port 53 before declaring the fix complete.'",
         "AI's diagnosis was correct and directly evidenced; edited to add a verification step reviewers want before sign-off on security-related ACL changes."),
"C017": ("Accepted", "", "Correct; missing A record is unambiguous from the DNS zone check."),
"C018": ("Accepted", "", "Correct; missing static route is directly shown in show ip route."),
"C019": ("Rejected",
         "OSPF IS configured on the interface (ip ospf 1 area 0 is present); the real problem is a subnet mask mismatch (/29 vs /30) between R1 and R2, which prevents the adjacency from forming even though OSPF is running.",
         "AI concluded 'OSPF not enabled' from an empty neighbor table alone, without reading the more specific detail in show_output that OSPF WAS configured on the interface but with a typo'd mask. This is a case of the AI reaching for the most common explanation for 'no OSPF neighbors' instead of reading the specific evidence given, and it's exactly the kind of error the workflow's rule checker is designed to catch independently (see rule_checker.py mask-mismatch check)."),
"C020": ("Accepted", "", "Correct; the failed ping to the configured next-hop is direct evidence."),
"C021": ("Edited",
         "Same root cause, reviewer tightened confidence language: kept at medium but added 'confirm by temporarily removing the route-map and re-testing' as an explicit validation step before deploying the fix in production.",
         "AI's diagnosis was correct given the traceroute asymmetry; edited to require validation before a production change, per team policy on policy-routing edits."),
"C022": ("Accepted", "", "Correct; the ACL only permitting 443 and the climbing implicit-deny counter are decisive evidence."),
"C023": ("Rejected",
         "The ACL DOES include a deny statement for host 10.10.12.50 (line 20), but a broader permit for the whole subnet (line 10) comes first and matches before the deny is ever evaluated. It's a statement-ORDER problem, not a missing statement.",
         "AI said the deny line was missing entirely, but the show_output clearly listed both lines with their order. This is a comprehension error, not a knowledge gap -- the fix the AI proposed (re-add a deny) would have done nothing, since a deny for that host already existed further down the list."),
"C024": ("Accepted", "", "Correct; the 'out' vs 'in' direction is explicit in the running config."),
"C025": ("Edited",
         "Same root cause, reviewer added a preferred fix: recommend a reflexive ACL as the primary option rather than a second static permit line, since it's the more correct long-term fix for return traffic.",
         "AI's diagnosis was correct; edited to prefer the safer, standard fix (reflexive ACL) over a second broad static permit that would widen the attack surface."),
"C026": ("Accepted", "", "Correct; missing NAT inside/outside interface roles are directly shown."),
"C027": ("Rejected",
         "NAT overload IS enabled; the problem is that access-list 1 only matches the first 16 addresses of the /24 subnet (wrong wildcard mask 0.0.0.15 instead of 0.0.0.255), so most hosts are never selected for translation.",
         "AI concluded NAT was 'not enabled at all,' but the show_output explicitly included the ip nat inside source list 1 ... overload line, proving NAT was configured. The actual defect was in the ACL's wildcard mask, which the AI did not examine closely enough. Proposed fix would have been a no-op since NAT was already on."),
"C028": ("Accepted", "", "Correct; missing static NAT/port-forward entry is unambiguous."),
"C029": ("Accepted", "", "Correct and high-severity; matches the WLAN interface mapping evidence exactly."),
"C030": ("Edited",
         "Corrected root cause: affected laptops are using a STALE CACHED Wi-Fi profile from last semester, not a RADIUS shared-secret mismatch on the WLC side (a secret mismatch would fail ALL clients, not just a subset).",
         "AI proposed a shared-secret mismatch, but that would cause every client to fail, not just a subset with old cached profiles. Kept as 'Edited' rather than 'Rejected' because the AI correctly identified the layer (802.1X/RADIUS, Layer 7) and the diagnostic direction, just not the precise mechanism -- the reviewer's correction is a refinement of a mostly-right answer."),
}

FIELDS = ["case_id","review_status","corrected_root_cause","reviewer_notes"]

with open("/home/claude/netsage_ai/review/human_review.csv", "w", newline="") as f:
    w = csv.DictWriter(f, fieldnames=FIELDS)
    w.writeheader()
    for case_id, (status, corrected, notes) in REVIEW.items():
        w.writerow({"case_id": case_id, "review_status": status,
                    "corrected_root_cause": corrected, "reviewer_notes": notes})

from collections import Counter
print(Counter(v[0] for v in REVIEW.values()))
print(f"Wrote {len(REVIEW)} review rows.")
