"""
NetSage AI - Dashboard Builder
Loads cases.csv, ai_diagnoses.csv, rule_checker_results.csv, human_review.csv
into their own sheets, then builds a Dashboard sheet with:
  - case counts by issue type / category
  - severity breakdown
  - human review outcome counts (Accepted/Edited/Rejected)
  - AI agreement rate (Accepted / total)
  - a bar chart of cases by category and a pie chart of review outcomes
All summary numbers use live formulas (SUMIFS/COUNTIFS) referencing the raw
data sheets, per the workbook conventions for this environment.
"""
import csv
import openpyxl
from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
from openpyxl.chart import BarChart, PieChart, Reference
from openpyxl.utils import get_column_letter

BASE = "/home/claude/netsage_ai"
OUT = f"{BASE}/dashboard/NetSage_AI_Dashboard.xlsx"

FONT = "Arial"
HEADER_FILL = PatternFill("solid", fgColor="1F4E78")
HEADER_FONT = Font(name=FONT, bold=True, color="FFFFFF", size=11)
TITLE_FONT = Font(name=FONT, bold=True, size=16, color="1F4E78")
LABEL_FONT = Font(name=FONT, bold=True, size=11)
BODY_FONT = Font(name=FONT, size=10)
THIN = Side(style="thin", color="D9D9D9")
BORDER = Border(left=THIN, right=THIN, top=THIN, bottom=THIN)


def load_csv(path):
    with open(path, newline="") as f:
        r = csv.reader(f)
        return list(r)


def coerce(val):
    if val == "True":
        return True
    if val == "False":
        return False
    return val


def write_sheet(wb, name, rows):
    ws = wb.create_sheet(name)
    for r_idx, row in enumerate(rows, start=1):
        for c_idx, val in enumerate(row, start=1):
            if r_idx > 1:
                val = coerce(val)
            cell = ws.cell(row=r_idx, column=c_idx, value=val)
            cell.font = HEADER_FONT if r_idx == 1 else BODY_FONT
            if r_idx == 1:
                cell.fill = HEADER_FILL
                cell.alignment = Alignment(horizontal="center")
            cell.border = BORDER
    for c_idx, header in enumerate(rows[0], start=1):
        width = max(12, min(42, max(len(str(row[c_idx-1])) for row in rows) + 2))
        ws.column_dimensions[get_column_letter(c_idx)].width = width
    ws.freeze_panes = "A2"
    return ws


def col_letter(rows, header_name):
    return get_column_letter(rows[0].index(header_name) + 1)


def main():
    cases = load_csv(f"{BASE}/data/cases.csv")
    ai = load_csv(f"{BASE}/data/ai_diagnoses.csv")
    rules = load_csv(f"{BASE}/data/rule_checker_results.csv")
    review = load_csv(f"{BASE}/review/human_review.csv")

    wb = openpyxl.Workbook()
    wb.remove(wb.active)

    ws_cases = write_sheet(wb, "Cases", cases)
    ws_ai = write_sheet(wb, "AI_Diagnoses", ai)
    ws_rules = write_sheet(wb, "Rule_Checker", rules)
    ws_review = write_sheet(wb, "Human_Review", review)

    n_cases = len(cases) - 1     # data rows
    n_review = len(review) - 1

    cat_col = col_letter(cases, "category")
    sev_col = col_letter(cases, "severity")
    status_col = col_letter(review, "review_status")
    clean_col = col_letter(rules, "clean")

    # ---------------- Dashboard sheet ----------------
    ws = wb.create_sheet("Dashboard", 0)
    ws.sheet_view.showGridLines = False
    ws["B2"] = "NetSage AI — Project Dashboard"
    ws["B2"].font = TITLE_FONT
    ws["B3"] = "Junior-engineer troubleshooting assistant with mandatory human review"
    ws["B3"].font = Font(name=FONT, italic=True, size=10, color="666666")

    # --- KPI row ---
    kpis = [
        ("Total Cases", f"=COUNTA(Cases!A2:A{len(cases)})"),
        ("Accepted", f'=COUNTIF(Human_Review!{status_col}2:{status_col}{len(review)},"Accepted")'),
        ("Edited", f'=COUNTIF(Human_Review!{status_col}2:{status_col}{len(review)},"Edited")'),
        ("Rejected", f'=COUNTIF(Human_Review!{status_col}2:{status_col}{len(review)},"Rejected")'),
        ("AI Agreement Rate",
         f'=COUNTIF(Human_Review!{status_col}2:{status_col}{len(review)},"Accepted")/COUNTA(Human_Review!{status_col}2:{status_col}{len(review)})'),
        ("Rule-Checker Clean Rate",
         f'=COUNTIF(Rule_Checker!{clean_col}2:{clean_col}{len(rules)},TRUE)/COUNTA(Rule_Checker!{clean_col}2:{clean_col}{len(rules)})'),
    ]
    start_row = 5
    for i, (label, formula) in enumerate(kpis):
        col = 2 + i  # start at column B
        c1 = ws.cell(row=start_row, column=col, value=label)
        c1.font = LABEL_FONT
        c1.alignment = Alignment(horizontal="center", wrap_text=True)
        c1.fill = PatternFill("solid", fgColor="D9E2F3")
        c1.border = BORDER
        c2 = ws.cell(row=start_row + 1, column=col, value=formula)
        c2.font = Font(name=FONT, bold=True, size=14, color="1F4E78")
        c2.alignment = Alignment(horizontal="center")
        c2.border = BORDER
        if "Rate" in label:
            c2.number_format = "0.0%"
        ws.column_dimensions[get_column_letter(col)].width = 16

    # --- Cases by category table (for bar chart) ---
    cat_header_row = 10
    ws.cell(row=cat_header_row, column=2, value="Cases by Issue Type").font = LABEL_FONT
    categories = sorted(set(r[cases[0].index("category")] for r in cases[1:]))
    ws.cell(row=cat_header_row + 1, column=2, value="Category").font = HEADER_FONT
    ws.cell(row=cat_header_row + 1, column=2).fill = HEADER_FILL
    ws.cell(row=cat_header_row + 1, column=3, value="Count").font = HEADER_FONT
    ws.cell(row=cat_header_row + 1, column=3).fill = HEADER_FILL
    for i, cat in enumerate(categories):
        r = cat_header_row + 2 + i
        ws.cell(row=r, column=2, value=cat).font = BODY_FONT
        formula = f'=COUNTIF(Cases!{cat_col}2:{cat_col}{len(cases)},B{r})'
        ws.cell(row=r, column=3, value=formula).font = BODY_FONT

    cat_last_row = cat_header_row + 1 + len(categories)

    # --- Review outcome table (for pie chart) ---
    rev_header_row = cat_header_row
    rev_col_b = 6  # column F
    ws.cell(row=rev_header_row, column=rev_col_b, value="Human Review Outcomes").font = LABEL_FONT
    ws.cell(row=rev_header_row + 1, column=rev_col_b, value="Outcome").font = HEADER_FONT
    ws.cell(row=rev_header_row + 1, column=rev_col_b).fill = HEADER_FILL
    ws.cell(row=rev_header_row + 1, column=rev_col_b + 1, value="Count").font = HEADER_FONT
    ws.cell(row=rev_header_row + 1, column=rev_col_b + 1).fill = HEADER_FILL
    outcomes = ["Accepted", "Edited", "Rejected"]
    for i, outcome in enumerate(outcomes):
        r = rev_header_row + 2 + i
        col_letter_out = get_column_letter(rev_col_b)
        ws.cell(row=r, column=rev_col_b, value=outcome).font = BODY_FONT
        formula = f'=COUNTIF(Human_Review!{status_col}2:{status_col}{len(review)},{col_letter_out}{r})'
        ws.cell(row=r, column=rev_col_b + 1, value=formula).font = BODY_FONT

    rev_last_row = rev_header_row + 1 + len(outcomes)

    # --- Severity table ---
    sev_header_row = cat_last_row + 3
    ws.cell(row=sev_header_row, column=2, value="Cases by Severity").font = LABEL_FONT
    ws.cell(row=sev_header_row + 1, column=2, value="Severity").font = HEADER_FONT
    ws.cell(row=sev_header_row + 1, column=2).fill = HEADER_FILL
    ws.cell(row=sev_header_row + 1, column=3, value="Count").font = HEADER_FONT
    ws.cell(row=sev_header_row + 1, column=3).fill = HEADER_FILL
    severities = ["High", "Medium", "Low"]
    for i, sev in enumerate(severities):
        r = sev_header_row + 2 + i
        ws.cell(row=r, column=2, value=sev).font = BODY_FONT
        formula = f'=COUNTIF(Cases!{sev_col}2:{sev_col}{len(cases)},B{r})'
        ws.cell(row=r, column=3, value=formula).font = BODY_FONT

    # --- Charts ---
    bar = BarChart()
    bar.title = "Cases by Issue Type"
    bar.y_axis.title = "Cases"
    bar.x_axis.title = "Category"
    data = Reference(ws, min_col=3, min_row=cat_header_row + 1, max_row=cat_last_row)
    cats = Reference(ws, min_col=2, min_row=cat_header_row + 2, max_row=cat_last_row)
    bar.add_data(data, titles_from_data=True)
    bar.set_categories(cats)
    bar.height, bar.width = 8, 16
    ws.add_chart(bar, f"B{sev_header_row + 6}")

    pie = PieChart()
    pie.title = "Human Review Outcomes"
    data = Reference(ws, min_col=rev_col_b + 1, min_row=rev_header_row + 1, max_row=rev_last_row)
    cats = Reference(ws, min_col=rev_col_b, min_row=rev_header_row + 2, max_row=rev_last_row)
    pie.add_data(data, titles_from_data=True)
    pie.set_categories(cats)
    pie.height, pie.width = 8, 12
    ws.add_chart(pie, f"F{sev_header_row + 6}")

    for col, w in [("A", 3), ("B", 18), ("C", 12), ("D", 10), ("E", 10), ("F", 18), ("G", 10)]:
        ws.column_dimensions[col].width = w

    wb.save(OUT)
    print(f"Saved {OUT}")


if __name__ == "__main__":
    main()
